<?php

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Simi_SimiStripeIntegrationGraphQl',
    __DIR__
);
